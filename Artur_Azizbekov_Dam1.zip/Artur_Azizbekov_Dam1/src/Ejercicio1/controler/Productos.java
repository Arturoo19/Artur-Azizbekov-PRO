package Ejercicio1.controler;

import java.util.ArrayList;
import java.util.Scanner;

public class Productos {
    static Scanner scanner = new Scanner(System.in);
    ArrayList<Object[]> listaProductos = new ArrayList<>();

    public void agregarProductos(){
        System.out.println("Escribe el nombre de producto:");
        String nombre = scanner.next();
        System.out.println("Escribe el precio de producto:");
        double precio = scanner.nextDouble();
        Object[] producto = new Object[]{nombre,precio};
        for (Object[] item : listaProductos){
            if (item[0].equals(nombre)){
                System.out.println("Ya existe este producto");
                return;
            } else {
                listaProductos.add(producto);
            }
        }


    }
    public void listarProductos(){
        for (Object[] item : listaProductos){
            System.out.println("Nombre:"+item[0]+" Precio:"+item[1]);
        }
    }
    public void precioMinimo(){
        System.out.println("Introduce el precio minimo:");
        double precioIntroducido = scanner.nextDouble();
        for (Object[] item: listaProductos) {
            if ((int)item[1] <= precioIntroducido){
                System.out.println("Nombre:"+item[0]+ " Precio:"+item[1]);
            }
        }
    }
    /*public void sortarProductos(){
        Object[] productos = new Object[]{listaProductos};
        listaProductos.sort((n1,n2) -> Integer );
    }*/

}
