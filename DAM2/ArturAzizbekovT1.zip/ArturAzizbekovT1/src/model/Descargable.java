package model;

public interface Descargable {

    double calcularTiempoDescarga(double velocidadInternet);

    double obtenerTamañoGB();
}
