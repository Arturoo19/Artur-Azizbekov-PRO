package model;

public enum  Prioridad {
    BAJA, MEDIA, ALTA
}
