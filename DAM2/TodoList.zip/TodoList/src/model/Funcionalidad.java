package model;

public interface Funcionalidad {
    void metodo1();
}
