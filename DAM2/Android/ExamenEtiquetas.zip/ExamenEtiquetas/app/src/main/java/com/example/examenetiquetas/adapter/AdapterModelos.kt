package com.example.examenetiquetas.adapter

class AdapterModelos {

}