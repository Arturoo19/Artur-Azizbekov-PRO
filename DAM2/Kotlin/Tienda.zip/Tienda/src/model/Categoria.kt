package model

enum class Categoria {
    Tecnologia,Muebles,Ropa,Generica
}