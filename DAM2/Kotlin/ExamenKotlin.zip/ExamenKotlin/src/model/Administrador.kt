package model

class Administrador(id:Int,nombre:String, var clave:Int)
    :Persona(id, nombre) {
    fun autorizacion(clavePedido: Int):Boolean{
        if (clavePedido!=clave){
            println("Denegado")
            return false
        }else{
            return true
        }
    }

}