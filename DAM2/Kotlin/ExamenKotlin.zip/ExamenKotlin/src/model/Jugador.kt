package model

class Jugador(id:Int,nombre:String,)
    :Persona(id, nombre) {
    var valor:Int? = null
    var posicion:String? = null
    var precioJugador:Int? = null
    override fun mostrarDatos() {
        super.mostrarDatos()
        println("Valor: $valor")
        println("Posicion: $posicion")
    }
    constructor(id: Int,nombre: String,valor:Int):this(id, nombre){
        this.valor = valor
    }
    constructor(id: Int,nombre: String,posicion:String,precioJugador:Int):this(id, nombre){
        this.posicion = posicion
        this.precioJugador = precioJugador
    }

}