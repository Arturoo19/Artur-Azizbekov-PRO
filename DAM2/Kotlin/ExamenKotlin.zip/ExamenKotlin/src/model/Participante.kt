package model

import controller.Fantasy

class Participante(id:Int,nombre:String,var puntos:Int)
    :Persona(id, nombre) {
        var presupuesto:Int = 10000000
        var plantilla = arrayListOf<Jugador>()




    override fun mostrarDatos() {
        super.mostrarDatos()
        println("Puntos: $puntos")
        println("Presupuesto: $presupuesto")
        println("Plantilla: $plantilla")
    }

    fun agregarJugadores(jugador: Jugador){
        var fantasy = Fantasy()
        if ((presupuesto- jugador.valor!!)>=0){
            fantasy.agregarJugador()
        }
    }


}