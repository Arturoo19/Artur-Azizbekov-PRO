package controller

import model.Jugador
import model.Participante

class Fantasy {
    var listaJugadores = arrayListOf<Jugador>()
    var puntuaciones = arrayListOf<Jugador>()


    fun plantillaCompleta():Boolean{
        if (listaJugadores.size==6){
            return true
        }
        return false
    }
    fun agregarJugador(){
        if (listaJugadores.size<6){
            listaJugadores.add(Jugador(1,"Marc-André ter Stegen", "Portero",3000000))
            println("Jugador agregado")
        }else{
            println("Tienes plantilla completa")
        }
    }
    fun listarJugadores(){
        listaJugadores.forEach {
            if (it.valor!! >=3000000){
                println(it)
            }
        }
    }
    fun puntuarJugadores(){
        puntuaciones.add(Jugador(1,"Marc-André ter Stegen", 10))
        puntuaciones.add(Jugador(2,"Ronald Araújo",0))
        puntuaciones.add(Jugador(3,"Eric García",3))
        puntuaciones.add(Jugador(4,"Pedri",23))
        puntuaciones.add(Jugador(5,"Robert Lewandowski",15))
        puntuaciones.add(Jugador(6,"Courtois",1))
        puntuaciones.add(Jugador(7,"David Alaba",5))
        puntuaciones.add(Jugador(8,"Jesús Vallejo",10))
        puntuaciones.add(Jugador(9,"Luka Modric",5))
        puntuaciones.add(Jugador(10,"Karim Benzema",10))
        puntuaciones.add(Jugador(11,"Ledesma",6))
        puntuaciones.add(Jugador(12,"Juan Cala",3))
        puntuaciones.add(Jugador(13,"Zaldua",6))
        puntuaciones.add(Jugador(14,"Alez Fernández",9))
        puntuaciones.add(Jugador(15, "Choco Lozano", 4))
        puntuaciones.add(Jugador(16,"Rajković",3))
        puntuaciones.add(Jugador(17,"Raíllo",6))
        puntuaciones.add(Jugador(18,"Maffeo",0))
        puntuaciones.add(Jugador(19,"Ruiz de Galarreta",7))
        puntuaciones.add(Jugador(26,"Ángel", 4))
        puntuaciones.add(Jugador(20,"Remiro",3))
        puntuaciones.add(Jugador(21,"Elustondo",5))
        puntuaciones.add(Jugador(22,"Zubeldia",6))
        puntuaciones.add(Jugador(23,"Zubimendi",7))
        puntuaciones.add(Jugador(24,"Take Kubo", 4))

    }

    fun iniciarJuego(){

    }
    fun contarPuntos(participante: Participante){
        var puntosFinal = 0
        if (participante.plantilla.size==6){
            for (it in puntuaciones){
                puntosFinal += it.valor
            }
        }
    }
    fun agregarParticipante(){

    }
}